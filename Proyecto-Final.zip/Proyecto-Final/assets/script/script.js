//Inicio del DOM
$(document).ready(function () {
  // Verificar estado de autenticación al cargar la página

  const email = localStorage.getItem("email");
  if (!email) {
    $("#no-registrado").removeClass("d-none");
    $("#mis-rutinas").addClass("d-none");
    $("#ver-ejercicios").addClass("d-none");
    $("#crear-rutina").addClass("d-none");
    $(".log").addClass("d-none");
    $(".no-log").removeClass("d-none");
  } else {
    $("#no-registrado").addClass("d-none");
    $(".log").removeClass("d-none");
    $(".no-log").addClass("d-none");
  }

  //vacia los input
  $(
    "#email, #password, #nombre, #email_registro, #password_registro, #password_repetir"
  ).val("");

  //esconde formulario de inicio sesion y muestra el de registro
  $(".crear_cuenta").click(function () {
    $(".login").hide();
    $(".registro").show();
  });

  //esconde formulario de registro y muestra el de inicio de sesion
  $(".sesion").click(function () {
    $(".registro").hide();
    $(".login").show();
  });

  //esconde formulario de inicio sesion y muestra el de nueva contraseña
  $("#recuperar-contraseña").click(function () {
    $(".login").hide();
    $(".olvidado").show();
  });

  //esconde el formulario de nueva contraseña y muestra el de inicio de sesion
  $(".sesion").click(function () {
    $(".olvidado").hide();
    $(".login").show();
  });

  //Si esta logeado y esta en ese ventana enseña los datos del usuario
  if (window.location.href.includes("datosUsuario.html")) {
    cargarDatos(localStorage.getItem("email"));
  }

  if (window.location.href.includes("rutinas.html")) {
    cargarRutinasUsuario();
    $("#btn-volver").click(function () {
      $("#ver-ejercicios").hide();
      $("#mis-rutinas").show();
    });
  }
  //Cierra sesion
  $("#cerrar_sesion").click(function () {
    cerrar_sesion();
  });

  //Envia formulario de inicio de sesion
  $("#inicio_sesion").submit(function (e) {
    e.preventDefault();
    if (!validarInicio()) return;

    let email = $("#email").val();
    let contraseña = $("#password").val();
    envioDatosInicio(email, contraseña);
  });

  //Envia formulario de registro
  $("#registro").submit(function (e) {
    e.preventDefault();
    if (!validarRegistro()) return;

    let usuario = $("#nombre").val();
    let email = $("#email_registro").val();
    let contraseña = $("#password_registro").val();
    envioDatosRegistro(usuario, email, contraseña);
  });

  //Envia formulario de cambio de contraseña
  $("#recuperar_contraseña").submit(function (e) {
    e.preventDefault();
    if (!validarNuevaContraseña()) return;

    let email = $("#email_recuperacion").val();
    let nuevaContraseña = $("#nueva_contraseña").val();

    envioContraseña(email, nuevaContraseña);
  });

  //Carga los ejercicios
  if (window.location.href.includes("crear_rutina.html")) {
    cargarEjercicios();
  }

  //Carga los ejercicios de la rutina seleccionada
  $("#formRutina").submit(function (e) {
    e.preventDefault();
    if (!validarRutina()) return;
    guardarRutina();
  });

  $("");
});

/*==================================================
              Fin del DOM
  ==================================================*/

/*==================================================
                Validaciones
  ==================================================*/
//Funcion para validar el inicio de sesion
function validarInicio() {
  let valido = true;
  let email = $("#email");
  let contraseña = $("#password");

  let regexEmail = /^[\w.-]+@[a-zA-Z\d.-]+\.[a-zA-Z]{2,}$/;
  let regexContraseña = /^[A-Za-z\d]{8,16}$/;

  limpiarErrores(email, contraseña);

  if (!regexEmail.test(email.val())) {
    mostrarError(email, "Formato de email incorrecto");
    valido = false;
  }

  if (!regexContraseña.test(contraseña.val())) {
    mostrarError(
      contraseña,
      "La contraseña debe tener entre 8 y 16 caracteres"
    );
    valido = false;
  }

  return valido;
}

//Funcion para validar el registro
function validarRegistro() {
  let valido = true;
  let usuario = $("#nombre");
  let email = $("#email_registro");
  let contraseña = $("#password_registro");
  let repetirContraseña = $("#password_repetir");

  let regexUsuario = /^[a-zA-Z0-9_-]{3,16}$/;
  let regexContraseña = /^[A-Za-z\d]{8,16}$/;
  let regexEmail = /^[\w.-]+@[a-zA-Z\d.-]+\.[a-zA-Z]{2,}$/;

  limpiarErrores(usuario, email, contraseña, repetirContraseña);

  if (!regexUsuario.test(usuario.val())) {
    mostrarError(
      usuario,
      "El usuario debe tener entre 3 y 16 caracteres y no incluir espacios"
    );
    valido = false;
  }

  if (!regexEmail.test(email.val())) {
    mostrarError(email, "Formato de email incorrecto");
    valido = false;
  }

  if (!regexContraseña.test(contraseña.val())) {
    mostrarError(
      contraseña,
      "La contraseña debe tener entre 8 y 16 caracteres"
    );
    valido = false;
  }

  if (contraseña.val() !== repetirContraseña.val()) {
    mostrarError(repetirContraseña, "Las contraseñas no coinciden");
    valido = false;
  }

  return valido;
}

//Funcion para validar la nueva contraseña
function validarNuevaContraseña() {
  let valido = true;
  let nuevaContraseña = $("#nueva_contraseña");
  let repetirNueva = $("#repetir_nueva_contraseña");

  limpiarErrores(nuevaContraseña, repetirNueva);

  let regexNuevaContraseña = /^[A-Za-z\d]{8,16}$/;
  let regexrepetirNueva = /^[A-Za-z\d]{8,16}$/;

  if (!regexNuevaContraseña.test(nuevaContraseña.val())) {
    mostrarError(
      nuevaContraseña,
      "La contraseña debe tener entre 8 y 16 caracteres"
    );
    valido = false;
  }

  if (!regexrepetirNueva.test(repetirNueva.val())) {
    mostrarError(
      repetirNueva,
      "La contraseña debe tener entre 8 y 16 caracteres"
    );
    valido = false;
  }

  if (nuevaContraseña.val() !== repetirNueva.val()) {
    mostrarError(repetirNueva, "Las contraseñas no coinciden");
    valido = false;
  }

  return valido;
}

//Funcion para validar la rutina
function validarRutina() {
  let valido = true;
  let nombreRutina = $("#nombre_rutina");
  let nivel = $("#nivel_rutina");
  const seriesInputs = document.querySelectorAll(".series-input");
  const repeticionesInputs = document.querySelectorAll(".repeticiones-input");
  const descansoInputs = document.querySelectorAll(".descanso-input");

  let regexNombreRutina = /^[\w\s-]{3,30}$/;

  if (!regexNombreRutina.test(nombreRutina.val())) {
    alert(
      "El nombre de la rutina debe tener entre 3 y 30 caracteres y no contener caracteres especiales."
    );
    valido = false;
  }

  if (!nivel.val() || nivel.val() === "0") {
    alert("Debes seleccionar un nivel para la rutina.");
    valido = false;
  }

  return valido;
}

//Funcion para mostrar errores
function mostrarError(campo, mensaje) {
  if (campo.next(".error").length === 0) {
    campo.after(`<span class="error text-danger small">${mensaje}</span>`);
  }
}

//Funcion para limpiar errores
function limpiarErrores(...campos) {
  campos.forEach((campo) => {
    campo.next(".error").remove();
  });
}

/*==================================================
              Fin de las validaciones
  ==================================================*/

/*==================================================
              Funciones de autenticacion
  ==================================================*/

//Envio de datos de inicio de sesion
async function envioDatosInicio(email, contraseña) {
  try {
    let datos = JSON.stringify({ email: email, password: contraseña });
    let url = new URL(
      "assets/php/controlador/controlador_inicio_sesion.php",
      window.location.href
    );
    let opciones = {
      method: "POST",
      body: datos,
      headers: {
        "Content-type": "application/json",
      },
    };

    let response = await fetch(url, opciones);

    if (!response.ok) {
      throw new Error(
        `Error en la solicitud: ${response.status} - ${response.statusText}`
      );
    }

    const data = await response.json();

    if (data.exito) {
      localStorage.setItem("email", email);
      $(".log").show();
      $(".no-log").hide();
      window.location.href = "index.html";
    } else {
      alert(data.message);
    }
  } catch (error) {
    console.error("Hubo un problema con la solicitud:", error);
  }
}

//Envio de datos de registro
async function envioDatosRegistro(usuario, email, contraseña) {
  try {
    let datos = JSON.stringify({
      nombre: usuario,
      email: email,
      password: contraseña,
    });
    let url = new URL(
      "assets/php/controlador/controlador_registro.php",
      window.location.href
    );
    let opciones = {
      method: "POST",
      body: datos,
      headers: {
        "Content-type": "application/json",
      },
    };

    let response = await fetch(url, opciones);
    if (!response.ok) {
      throw new Error("No se ha encontrado el archivo");
    }
    let data = await response.json();

    if (data.exito) {
      localStorage.setItem("email", email);
      $(".log").show();
      $(".no-log").hide();
      window.location.href = "index.html";
    } else {
      alert(data.message);
    }
  } catch (error) {
    console.error("Error en el registro:", error);
    alert("Ocurrió un error al registrarse. Inténtalo de nuevo.");
  }
}

//Envio de datos de nueva contraseña
async function envioContraseña(email, nuevaContraseña) {
  try {
    let datos = JSON.stringify({ email: email, password: nuevaContraseña });
    let url = new URL(
      "assets/php/controlador/controlador_recuperar.php",
      window.location.href
    );
    let opciones = {
      method: "POST",
      body: datos,
      headers: {
        "Content-type": "application/json",
      },
    };

    console.log(datos);
    let response = await fetch(url, opciones);

    console.log(response);
    if (!response.ok) throw new Error("No se ha encontrado el archivo");

    let data = await response.json();

    console.log(data);
    if (data.exito) {
      window.location.href = "inicio_sesion.html";
    } else {
    }
  } catch (error) {
    console.error("Error en el registro de contraseña:", error);
    alert("Ocurrió un error al guardar la contraseña. Inténtalo de nuevo.");
  }
}

/*Funcion para cargar los datos del usuario, recupera los 
datos del usuario logeado y los muestra en el html*/
async function cargarDatos(email) {
  try {
    let url = new URL(
      "assets/php/controlador/controlador_log.php",
      window.location.href
    );
    let datos = JSON.stringify({ email: email });
    let opciones = {
      method: "POST",
      body: datos,
      headers: {
        "Content-type": "application/json",
      },
    };

    let response = await fetch(url, opciones);
    if (!response.ok) throw new Error("No se ha encontrado el archivo");

    let data = await response.json();
    console.log(data);

    if (data.exito) {
      let usuario = data.usuario;
      document.getElementById("nombre_usuario").innerText = usuario.nombre;
      document.getElementById("email_usuario").innerText = usuario.email;
    } else {
      console.error("Error al cargar los datos del usuario");
    }
  } catch (error) {
    console.error("Error al cargar los datos del usuario:", error);
  }
}

//Funcion para cerrar sesion
async function cerrar_sesion() {
  try {
    let url = new URL(
      "assets/php/controlador/cerrar_sesion.php",
      window.location.href
    );
    let response = await fetch(url);
    let data = await response.json();

    if (data.exito) {
      localStorage.removeItem("email");
      $(".log").hide();
      $(".no-log").show();
      window.location.href = "index.html";
    } else {
      alert("Error al cerrar sesión");
    }
  } catch (error) {
    console.error("Error al cerrar sesión:", error);
  }
}

/*==================================================
            Fin funciones de autenticacion
  ==================================================*/

/*==================================================
               Funciones ejercicios
  ==================================================*/

// Variables de estado
let paginaActual = 1;
const filaPorPagina = 10;
let ejerciciosGlobal = [];
let ejerciciosSeleccionados = [];

// Función principal para cargar ejercicios
async function cargarEjercicios() {
  try {
    const url = new URL(
      "assets/php/controlador/controlador_rutina.php",
      window.location.href
    );
    const response = await fetch(url);
    if (!response.ok) throw new Error("No se ha encontrado el archivo");
    const ejercicios = await response.json();

    iniciarPaginacion(ejercicios);
  } catch (error) {
    console.error("Error al cargar los ejercicios:", error);
    document.getElementById("tabla-ejercicios-container").textContent =
      "Error al cargar los ejercicios.";
  }
}

// Función para iniciar la paginación
function iniciarPaginacion(ejercicios) {
  ejerciciosGlobal = ejercicios;
  renderTabla(paginaActual);
}

// Función para renderizar la tabla de ejercicios
function renderTabla(pagina) {
  const contenedor = document.getElementById("tabla-ejercicios-container");
  contenedor.innerHTML = "";

  const tabla = crearTablaEjercicios(ejerciciosGlobal, pagina);
  contenedor.appendChild(tabla);
  contenedor.appendChild(crearPaginacion());
  contenedor.appendChild(crearBotonAgregar());
}

// Función para crear la tabla de ejercicios
function crearTablaEjercicios(ejercicios, pagina) {
  const tabla = document.createElement("table");
  tabla.classList.add("tabla-ejercicios");

  const thead = document.createElement("thead");
  const encabezado = document.createElement("tr");
  ["Nombre", "Descripción", "Equipamiento", "Dificultad"].forEach((titulo) => {
    const th = document.createElement("th");
    th.textContent = titulo;
    encabezado.appendChild(th);
  });
  thead.appendChild(encabezado);
  tabla.appendChild(thead);

  const tbody = document.createElement("tbody");
  const inicio = (pagina - 1) * filaPorPagina;
  const fin = inicio + filaPorPagina;
  const ejerciciosPagina = ejercicios.slice(inicio, fin);

  ejerciciosPagina.forEach((ejercicio) => {
    const fila = document.createElement("tr");
    fila.classList.add("fila-ejercicio");
    fila.dataset.id = ejercicio.id_ejercicio;

    ejerciciosSeleccionados.forEach((e) => {
      if (e.nombre === ejercicio.nombre) {
        fila.classList.add("seleccionado");
      }
    });

    fila.addEventListener("click", () => toggleSeleccion(fila, ejercicio));

    ["nombre", "descripcion", "equipamiento", "dificultad"].forEach((campo) => {
      const td = document.createElement("td");
      td.textContent = ejercicio[campo];
      fila.appendChild(td);
    });
    tbody.appendChild(fila);
  });

  tabla.appendChild(tbody);
  return tabla;
}

// Función para crear la paginación
function crearPaginacion() {
  const totalPag = Math.ceil(ejerciciosGlobal.length / filaPorPagina);
  const paginacion = document.createElement("div");
  paginacion.style.marginTop = "10px";

  if (paginaActual > 1) {
    const btnAnterior = document.createElement("button");
    btnAnterior.textContent = "Anterior";
    btnAnterior.onclick = () => {
      paginaActual--;
      renderTabla(paginaActual);
    };
    paginacion.appendChild(btnAnterior);
  }

  if (paginaActual < totalPag) {
    const btnSiguiente = document.createElement("button");
    btnSiguiente.textContent = "Siguiente";
    btnSiguiente.style.marginLeft = "10px";
    btnSiguiente.onclick = () => {
      paginaActual++;
      renderTabla(paginaActual);
    };
    paginacion.appendChild(btnSiguiente);
  }

  return paginacion;
}

// Función para crear el botón de agregar ejercicios seleccionados
function crearBotonAgregar() {
  const btnAgregar = document.createElement("button");
  btnAgregar.textContent = "Añadir ejercicios seleccionados";
  btnAgregar.style.marginTop = "10px";
  btnAgregar.onclick = (event) => {
    event.preventDefault();
    mostrarEjerciciosSeleccionados();
  };
  return btnAgregar;
}

// Función para alternar la selección de un ejercicio
function toggleSeleccion(fila, ejercicio) {
  const index = ejerciciosSeleccionados.findIndex(
    (e) => e.id_ejercicio === ejercicio.id_ejercicio
  );

  if (index !== -1) {
    ejerciciosSeleccionados.splice(index, 1);
    fila.classList.remove("seleccionado");
  } else {
    ejerciciosSeleccionados.push(ejercicio);
    fila.classList.add("seleccionado");
  }
}

// Función para validar los ejercicios seleccionados
function validarEjercicios(ejercicios) {
  return ejercicios.every(
    (ej) => ej.id_ejercicio && ej.series && ej.repeticiones && ej.descanso
  );
}

// Función para mostrar los ejercicios seleccionados en una tabla
function mostrarEjerciciosSeleccionados() {
  if (ejerciciosSeleccionados.length === 0) {
    alert("Selecciona al menos un ejercicio.");
    return;
  }

  const tablaFinal = document.getElementById("tabla-ejercicios-final");
  tablaFinal.innerHTML = "";

  const tabla = document.createElement("table");
  tabla.classList.add("tabla-seleccion");

  const thead = document.createElement("thead");
  const encabezado = document.createElement("tr");
  ["Nombre", "Descripción", "Series", "Repeticiones", "Descanso (seg)"].forEach(
    (titulo) => {
      const th = document.createElement("th");
      th.textContent = titulo;
      encabezado.appendChild(th);
    }
  );
  thead.appendChild(encabezado);
  tabla.appendChild(thead);

  const tbody = document.createElement("tbody");

  const enModificacion = localStorage.getItem("modificar") === "true";
  const ejerciciosGuardados = enModificacion
    ? JSON.parse(localStorage.getItem("ejercicios_modificados")) || []
    : [];

  ejerciciosSeleccionados.forEach((ejercicio) => {
    const fila = document.createElement("tr");
    fila.dataset.id = ejercicio.id_ejercicio;

    const celdaNombre = document.createElement("td");
    celdaNombre.textContent = ejercicio.nombre;
    fila.appendChild(celdaNombre);

    const celdaDescripcion = document.createElement("td");
    celdaDescripcion.textContent = ejercicio.descripcion;
    fila.appendChild(celdaDescripcion);

    const datosPrevios = ejerciciosGuardados.find(
      (ej) =>
        ej.id_ejercicio == ejercicio.id_ejercicio ||
        ej.idEjercicio == ejercicio.id_ejercicio
    );

    fila.appendChild(
      crearCeldaInput("4", "input-series", "Series", datosPrevios?.series)
    );
    fila.appendChild(
      crearCeldaInput(
        "10",
        "input-repeticiones",
        "Reps",
        datosPrevios?.repeticiones
      )
    );
    fila.appendChild(
      crearCeldaInput(
        "60",
        "input-descanso",
        "Descanso (s)",
        datosPrevios?.descanso
      )
    );

    tbody.appendChild(fila);
  });

  tabla.appendChild(tbody);
  tablaFinal.appendChild(tabla);
}

// Función para crear una celda con un input
function crearCeldaInput(
  defaultValue,
  className,
  placeholder,
  valorModificado
) {
  const celda = document.createElement("td");
  const input = document.createElement("input");
  input.type = "number";
  input.min = "1";
  input.value = valorModificado || defaultValue;
  input.placeholder = placeholder;
  input.classList.add("input-estilo");
  if (className) input.classList.add(className);

  const label = document.createElement("span");
  label.className = "mobile-label";
  label.textContent = placeholder + ": ";
  label.style.display = "none";

  celda.appendChild(label);
  celda.appendChild(input);
  return celda;
}

// Función para guardar la rutina
async function guardarRutina() {
  try {
    const ejercicios = [];
    const email = localStorage.getItem("email");
    const nombre = $("#nombre_rutina").val();
    const nivel = $("#nivel_rutina").val();

    $("#tabla-ejercicios-final tbody tr").each(function () {
      const fila = $(this);
      ejercicios.push({
        id_ejercicio: parseInt(fila.data("id")),
        series: parseInt(fila.find(".input-series").val()) || 4,
        repeticiones: parseInt(fila.find(".input-repeticiones").val()) || 10,
        descanso: parseInt(fila.find(".input-descanso").val()) || 60,
      });
    });

    const response = await fetch(
      "assets/php/controlador/controlador_crear_rutina.php",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email,
          nombre: nombre,
          nivel: nivel,
          ejercicios: ejercicios,
        }),
      }
    );

    const resultado = await response.json();

    if (resultado.exito) {
      alert(resultado.mensaje);
      window.location.href = "index.html";
    } else {
      alert("Error: " + resultado.mensaje);
    }
  } catch (error) {
    console.error("Error:", error);
    alert("Error al guardar: " + error.message);
  }
}

// Función para mostrar la sección de "No registrado"
function mostrarSeccionNoRegistrado() {
  document.getElementById("mis-rutinas").style.display = "none";
  document.getElementById("no-registrado").style.display = "block";
}

// Función para mostrar las rutinas en la página
async function cargarRutinasUsuario() {
  let responseText = "";
  try {
    const email = localStorage.getItem("email");
    if (!email) {
      mostrarSeccionNoRegistrado();
      return;
    }

    const response = await fetch(
      "assets/php/controlador/controlador_get_rutinas.php",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({ email: email }),
      }
    );

    responseText = await response.text();

    if (!responseText.trim()) {
      throw new Error("La respuesta del servidor está vacía");
    }

    const resultado = JSON.parse(responseText);

    mostrarRutinas(resultado);
  } catch (error) {
    console.error("Error detallado:", {
      error: error,
      responseText: responseText || "No disponible",
    });

    let mensajeError = "Error al cargar las rutinas";
    if (error.message.includes("Usuario no encontrado")) {
      mensajeError = "Usuario no encontrado";
      mostrarSeccionNoRegistrado();
    } else if (error.message.includes("JSON")) {
      mensajeError = "Error al interpretar los datos del servidor";
    }

    mostrarMensajeError(mensajeError);
  }
}

function mostrarRutinas(resultado) {
  const rutinas = resultado.rutinas;
  const listaRutinas = document.getElementById("lista-rutinas");
  listaRutinas.innerHTML = "";

  if (!rutinas || rutinas.length === 0) {
    const divInfo = document.createElement("div");
    divInfo.className = "alert alert-info";

    const texto = document.createTextNode("Aún no tienes ninguna rutina. ");
    const enlace = document.createElement("a");
    enlace.href = "crear_rutina.html";
    enlace.textContent = "Crea tu primera rutina";
    enlace.classList.add("enlace-rutina");

    divInfo.appendChild(texto);
    divInfo.appendChild(enlace);
    listaRutinas.appendChild(divInfo);
    return;
  }

  rutinas.forEach((rutina) => {
    const card = document.createElement("div");
    card.className = "card mb-3";

    const cardBody = document.createElement("div");
    cardBody.className = "card-body";

    const titulo = document.createElement("h5");
    titulo.className = "card-title";
    titulo.textContent = rutina.nombre;

    const nivel = document.createElement("p");
    nivel.className = "card-text";
    nivel.textContent = `Nivel: ${rutina.nivel}`;

    const btnVer = document.createElement("button");
    btnVer.className = "btn btn-primary me-2 ver-ejercicios";
    btnVer.textContent = "Ver ejercicios";
    btnVer.dataset.id = rutina.id_rutina;

    const btnEliminar = document.createElement("button");
    btnEliminar.className = "btn btn-danger eliminar-rutina";
    btnEliminar.textContent = "Eliminar";
    btnEliminar.dataset.id = rutina.id_rutina;

    cardBody.appendChild(titulo);
    cardBody.appendChild(nivel);
    cardBody.appendChild(btnVer);
    cardBody.appendChild(btnEliminar);
    card.appendChild(cardBody);
    listaRutinas.appendChild(card);

    btnVer.addEventListener("click", async () => {
      document.getElementById("mis-rutinas").style.display = "none";
      document.getElementById("ver-ejercicios").style.display = "block";
      await cargarEjerciciosRutina(
        btnVer.dataset.id,
        rutina.nombre,
        rutina.nivel
      );
    });

    btnEliminar.addEventListener("click", async () => {
      if (confirm("¿Seguro que quieres eliminar esta rutina?")) {
        await eliminarRutina(btnEliminar.dataset.id);
      }
    });
  });
}

// Función para mostrar mensajes de error
function mostrarMensajeError(mensaje) {
  const listaRutinas = document.getElementById("lista-rutinas");
  listaRutinas.innerHTML = `
      <div class="alert alert-danger">
          ${mensaje}
      </div>
  `;
}

// Función para cargar los ejercicios de una rutina específica
async function cargarEjerciciosRutina(idRutina, nombreRutina, nivelRutina) {
  try {
    localStorage.setItem("id_rutina_modificada", idRutina);
    const response = await fetch(
      `assets/php/controlador/controlador_ejercicios_rutina.php?id=${idRutina}`
    );

    if (!response.ok) throw new Error(`Error HTTP: ${response.status}`);
    const data = await response.json();
    if (!data.exito)
      throw new Error(data.mensaje || "Error al cargar ejercicios");

    const verEjerciciosDiv = document.getElementById("ver-ejercicios");
    verEjerciciosDiv.innerHTML = "";

    const titulo = document.createElement("h2");
    titulo.textContent = "Ejercicios de la Rutina";
    titulo.classList.add("mb-4");
    verEjerciciosDiv.appendChild(titulo);

    const tabla = document.createElement("table");
    tabla.classList.add("tabla-ejercicios", "responsive-table");

    const thead = document.createElement("thead");
    const trHead = document.createElement("tr");
    [
      "Ejercicio",
      "Equipamiento",
      "Series",
      "Repeticiones",
      "Descanso (s)",
    ].forEach((titulo) => {
      const th = document.createElement("th");
      th.textContent = titulo;
      trHead.appendChild(th);
    });
    thead.appendChild(trHead);
    tabla.appendChild(thead);

    const tbody = document.createElement("tbody");

    data.ejercicios.forEach((ejercicio) => {
      const fila = document.createElement("tr");
      fila.classList.add("fila-ejercicio");

      const crearCelda = (texto, label) => {
        const td = document.createElement("td");
        td.setAttribute("data-label", label);
        td.textContent = texto;
        return td;
      };

      const tdNombre = document.createElement("td");
      tdNombre.setAttribute("data-label", "Ejercicio");
      const strongNombre = document.createElement("strong");
      strongNombre.textContent = ejercicio.nombre;
      tdNombre.appendChild(strongNombre);
      if (ejercicio.descripcion) {
        const descripcion = document.createElement("p");
        descripcion.classList.add("mt-1", "mb-0");
        descripcion.textContent = ejercicio.descripcion;
        tdNombre.appendChild(descripcion);
      }
      fila.appendChild(tdNombre);

      fila.appendChild(
        crearCelda(ejercicio.equipamiento || "-", "Equipamiento")
      );
      fila.appendChild(crearCelda(ejercicio.series, "Series"));
      fila.appendChild(crearCelda(ejercicio.repeticiones, "Repeticiones"));
      fila.appendChild(crearCelda(ejercicio.descanso, "Descanso (s)"));

      tbody.appendChild(fila);
    });

    tabla.appendChild(tbody);
    verEjerciciosDiv.appendChild(tabla);

    localStorage.setItem("ejercicios", JSON.stringify(data.ejercicios));
    localStorage.setItem("nombreRutina", nombreRutina);
    localStorage.setItem("nivelRutina", nivelRutina);

    const btnVolver = document.createElement("button");
    btnVolver.classList.add("btn", "btn-secondary", "mt-3");
    btnVolver.textContent = "Volver a rutinas";
    btnVolver.addEventListener("click", () => {
      verEjerciciosDiv.style.display = "none";
      document.getElementById("mis-rutinas").style.display = "block";
    });

    const btnModificarEjercicios = document.createElement("button");
    btnModificarEjercicios.classList.add(
      "btn",
      "btn-secondary",
      "ms-0",
      "mt-3",
      "ms-sm-2"
    );
    btnModificarEjercicios.textContent = "Modificar ejercicios";
    btnModificarEjercicios.addEventListener("click", () => {
      modificarEjercicios();
    });

    verEjerciciosDiv.appendChild(btnVolver);
    verEjerciciosDiv.appendChild(btnModificarEjercicios);
    verEjerciciosDiv.style.display = "block";
    document.getElementById("mis-rutinas").style.display = "none";
  } catch (error) {
    alert(`Error al cargar ejercicios: ${error.message}`);

    const btnVolver = document.createElement("button");
    btnVolver.classList.add("btn", "btn-secondary", "mt-3");
    btnVolver.textContent = "Volver a rutinas";
    btnVolver.addEventListener("click", () => {
      verEjerciciosDiv.style.display = "none";
      document.getElementById("mis-rutinas").style.display = "block";
    });

    const errorDiv = document.createElement("div");
    errorDiv.classList.add("alert", "alert-danger", "mt-3");
    errorDiv.textContent = error.message;
    errorDiv.appendChild(btnVolver);
    verEjerciciosDiv.appendChild(errorDiv);
    verEjerciciosDiv.style.display = "block";
    document.getElementById("mis-rutinas").style.display = "none";
  }
}

// Función para eliminar una rutina
async function eliminarRutina(id_rutina) {
  const confirmacion = confirm(
    "¿Estás seguro de que quieres eliminar esta rutina? Esta acción no se puede deshacer."
  );
  if (!confirmacion) return;

  try {
    const url = new URL(
      "assets/php/controlador/controlador_eliminar_rutinas.php",
      window.location.href
    );
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ id_rutina }),
    });

    const resultado = await response.json();

    if (resultado.exito) {
      alert("Rutina eliminada correctamente.");
      cargarRutinasUsuario();
    } else {
      alert("Error al eliminar rutina: " + resultado.mensaje);
    }
  } catch (error) {
    console.error("Error eliminando rutina:", error);
    alert("Ocurrió un error al eliminar la rutina.");
  }
}

// Función para modificar los ejercicios de una rutina
function modificarEjercicios() {
  localStorage.setItem("modificar", "true");
  const ejercicios = JSON.parse(localStorage.getItem("ejercicios"));
  const nombreRutina = localStorage.getItem("nombreRutina");
  const nivelRutina = localStorage.getItem("nivelRutina");

  $(".modificar-rutina").remove();

  const seccionMod = document.createElement("section");
  seccionMod.classList.add("modificar-rutina");

  const titulo = document.createElement("h1");
  titulo.textContent = "Modificar rutina";
  seccionMod.appendChild(titulo);

  const form = document.createElement("form");
  form.id = "formRutina";
  form.method = "POST";
  form.action = "assets/php/controlador/controlador_modificar_rutina.php";

  const grupoNombre = document.createElement("div");
  grupoNombre.classList.add("input-group-custom");

  const labelNombre = document.createElement("label");
  labelNombre.setAttribute("for", "nombre_rutina");
  labelNombre.textContent = "Nombre de la Rutina:";
  grupoNombre.appendChild(labelNombre);

  const inputNombre = document.createElement("input");
  inputNombre.type = "text";
  inputNombre.id = "nombre_rutina";
  inputNombre.name = "nombre";
  inputNombre.classList.add("form-control");
  inputNombre.value = nombreRutina;
  grupoNombre.appendChild(inputNombre);

  form.appendChild(grupoNombre);

  const grupoNivel = document.createElement("div");
  grupoNivel.classList.add("input-group-custom");

  const labelNivel = document.createElement("label");
  labelNivel.setAttribute("for", "nivel_rutina");
  labelNivel.textContent = "Nivel:";
  grupoNivel.appendChild(labelNivel);

  const selectNivel = document.createElement("select");
  selectNivel.id = "nivel_rutina";
  selectNivel.name = "nivel";
  selectNivel.classList.add("form-select");

  const niveles = [
    { value: "0", text: "Elige nivel de rutina" },
    { value: "principiante", text: "Principiante" },
    { value: "intermedio", text: "Intermedio" },
    { value: "avanzado", text: "Avanzado" },
  ];

  niveles.forEach((nivel) => {
    const option = document.createElement("option");
    option.value = nivel.value;
    option.textContent = nivel.text;
    if (nivel.value === nivelRutina) {
      option.selected = true;
    }
    selectNivel.appendChild(option);
  });

  grupoNivel.appendChild(selectNivel);

  form.appendChild(grupoNivel);

  const contenedorEjercicios = document.createElement("div");
  contenedorEjercicios.id = "tabla-ejercicios-container";
  form.appendChild(contenedorEjercicios);

  const salto = document.createElement("br");
  form.appendChild(salto);

  const subtitulo = document.createElement("h3");
  subtitulo.textContent = "Ejercicios Seleccionados";
  form.appendChild(subtitulo);

  const contenedorFinal = document.createElement("div");
  contenedorFinal.id = "tabla-ejercicios-final";
  form.appendChild(contenedorFinal);

  const boton = document.createElement("button");
  boton.type = "submit";
  boton.textContent = "Actualizar rutina";
  boton.classList.add("btn", "btn-primary", "mt-3");
  boton.id = "btnModificarRutina";
  form.appendChild(boton);

  seccionMod.appendChild(form);
  document.querySelector("main").appendChild(seccionMod);

  $("#ver-ejercicios").hide();
  $(".seccion-modificar-rutina").show();

  const ejerciciosGuardados = ejercicios || [];
  ejerciciosSeleccionados = [...ejerciciosGuardados];
  cargarEjercicios();

  localStorage.setItem(
    "ejercicios_modificados",
    JSON.stringify(ejerciciosGuardados)
  );
  mostrarEjerciciosSeleccionados();
  $("#formRutina").on("submit", (event) => {
    event.preventDefault();
    if (validarRutina()) {
      modificarRutina();
    } else {
      alert("Por favor, completa todos los campos correctamente.");
    }
  });
}

async function modificarRutina() {
  const idRutina = localStorage.getItem("id_rutina_modificada");
  const nombreRutina = document.getElementById("nombre_rutina").value;
  const nivelRutina = document.getElementById("nivel_rutina").value;
  const ejerciciosSeleccionados = [];

  document
    .querySelectorAll("#tabla-ejercicios-final tbody tr")
    .forEach((fila) => {
      const idEjercicio = fila.getAttribute("data-id");
      const series = fila.querySelector(".input-series").value;
      const repeticiones = fila.querySelector(".input-repeticiones").value;
      const descanso = fila.querySelector(".input-descanso").value;

      ejerciciosSeleccionados.push({
        id_ejercicio: idEjercicio,
        series: series,
        repeticiones: repeticiones,
        descanso: descanso,
      });
    });
  if (!validarEjercicios(ejerciciosSeleccionados)) {
    alert("Por favor, completa todos los campos de los ejercicios.");
    return;
  }
  try {
    const url = new URL(
      "assets/php/controlador/controlador_modificar_rutina.php",
      window.location.href
    );
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        idRutina: idRutina,
        nombreRutina: nombreRutina,
        nivelRutina: nivelRutina,
        ejercicios: ejerciciosSeleccionados,
      }),
    });
    const resultado = await response.json();
    if (resultado.exito) {
      alert("Rutina modificada correctamente.");
      localStorage.removeItem("modificar");
      localStorage.removeItem("ejercicios_modificados");
      window.location.href = "rutinas.html";
    } else {
      alert("Error al modificar rutina: " + resultado.mensaje);
    }
  } catch (error) {
    console.error("Error al modificar la rutina:", error);
    alert("Ocurrió un error al modificar la rutina. Inténtalo de nuevo.");
  }
}

/*==================================================
              Fin funciones ejercicios
  ==================================================*/

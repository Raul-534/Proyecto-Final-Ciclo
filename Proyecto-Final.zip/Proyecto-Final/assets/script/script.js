//Inicio del DOM
$(document).ready(function () {
  //Si el usuario ya ha iniciado sesion, muestra el boton de cerrar sesion y esconde el de iniciar sesion
  if (localStorage.getItem("email")) {
    $(".log").show();
    $(".no-log").hide();
  } else {
    $(".log").hide();
    $(".no-log").show();
  }

  //vacia los input
  $(
    "#email, #password, #nombre, #email_registro, #password_registro, #password_repetir"
  ).val("");

  //esconde formulario de inicio sesion y muestra el de registro
  $(".crear_cuenta").click(function () {
    $(".login").hide();
    $(".registro").show();
  });

  //esconde formulario de registro y muestra el de inicio de sesion
  $(".sesion").click(function () {
    $(".registro").hide();
    $(".login").show();
  });

  //esconde formulario de inicio sesion y muestra el de nueva contraseña
  $("#recuperar-contraseña").click(function () {
    $(".login").hide();
    $(".olvidado").show();
  });

  //esconde el formulario de nueva contraseña y muestra el de inicio de sesion
  $(".sesion").click(function () {
    $(".olvidado").hide();
    $(".login").show();
  });

  //Si esta logeado y esta en ese ventana enseña los datos del usuario
  if (window.location.href.includes("datosUsuario.html")) {
    cargarDatos(localStorage.getItem("email"));
  }
  //Cierra sesion
  $("#cerrar_sesion").click(function () {
    cerrar_sesion();
  });

  //Envia formulario de inicio de sesion
  $("#inicio_sesion").submit(function (e) {
    e.preventDefault();
    if (!validarInicio()) return;

    let email = $("#email").val();
    let contraseña = $("#password").val();
    envioDatosInicio(email, contraseña);
  });

  //Envia formulario de registro
  $("#registro").submit(function (e) {
    e.preventDefault();
    if (!validarRegistro()) return;

    let usuario = $("#nombre").val();
    let email = $("#email_registro").val();
    let contraseña = $("#password_registro").val();
    envioDatosRegistro(usuario, email, contraseña);
  });

  //Envia formulario de cambio de contraseña
  $("#recuperar_contraseña").submit(function (e) {
    e.preventDefault();
    if (!validarNuevaContraseña()) return;

    let email = $("#email_recuperacion").val();
    let nuevaContraseña = $("#nueva_contraseña").val();

    envioContraseña(email, nuevaContraseña);
  });
});

/*==================================================
              Fin del DOM
  ==================================================*/

//Funcion para validar el inicio de sesion
function validarInicio() {
  let valido = true;
  let email = $("#email");
  let contraseña = $("#password");

  let regexEmail = /^[\w.-]+@[a-zA-Z\d.-]+\.[a-zA-Z]{2,}$/;
  let regexContraseña = /^[A-Za-z\d]{8,16}$/;

  limpiarErrores(email, contraseña);

  if (!regexEmail.test(email.val())) {
    mostrarError(email, "Formato de email incorrecto");
    valido = false;
  }

  if (!regexContraseña.test(contraseña.val())) {
    mostrarError(
      contraseña,
      "La contraseña debe tener entre 8 y 16 caracteres"
    );
    valido = false;
  }

  return valido;
}

//Funcion para validar el registro
function validarRegistro() {
  let valido = true;
  let usuario = $("#nombre");
  let email = $("#email_registro");
  let contraseña = $("#password_registro");
  let repetirContraseña = $("#password_repetir");

  let regexUsuario = /^[a-zA-Z0-9_-]{3,16}$/;
  let regexContraseña = /^[A-Za-z\d]{8,16}$/;
  let regexEmail = /^[\w.-]+@[a-zA-Z\d.-]+\.[a-zA-Z]{2,}$/;

  limpiarErrores(usuario, email, contraseña, repetirContraseña);

  if (!regexUsuario.test(usuario.val())) {
    mostrarError(
      usuario,
      "El usuario debe tener entre 3 y 16 caracteres y no incluir espacios"
    );
    valido = false;
  }

  if (!regexEmail.test(email.val())) {
    mostrarError(email, "Formato de email incorrecto");
    valido = false;
  }

  if (!regexContraseña.test(contraseña.val())) {
    mostrarError(
      contraseña,
      "La contraseña debe tener entre 8 y 16 caracteres"
    );
    valido = false;
  }

  if (contraseña.val() !== repetirContraseña.val()) {
    mostrarError(repetirContraseña, "Las contraseñas no coinciden");
    valido = false;
  }

  return valido;
}

//Funcion para validar la nueva contraseña
function validarNuevaContraseña() {
  let valido = true;
  let nuevaContraseña = $("#nueva_contraseña");
  let repetirNueva = $("#repetir_nueva_contraseña");

  limpiarErrores(nuevaContraseña, repetirNueva);

  let regexNuevaContraseña = /^[A-Za-z\d]{8,16}$/;
  let regexrepetirNueva = /^[A-Za-z\d]{8,16}$/;

  if (!regexNuevaContraseña.test(nuevaContraseña.val())) {
    mostrarError(
      nuevaContraseña,
      "La contraseña debe tener entre 8 y 16 caracteres"
    );
    valido = false;
  }

  if (!regexrepetirNueva.test(repetirNueva.val())) {
    mostrarError(
      repetirNueva,
      "La contraseña debe tener entre 8 y 16 caracteres"
    );
    valido = false;
  }

  if (nuevaContraseña.val() !== repetirNueva.val()) {
    mostrarError(repetirNueva, "Las contraseñas no coinciden");
    valido = false;
  }

  return valido;
}

function validarRutina() {
  let valido = true;
  let nombreRutina = $("#nombre_rutina");
  let nivel = $("#nivel_rutina");

  let regexNombreRutina = /^[a-zA-Z0-9_-]{3,16}$/;

  if (!regexNombreRutina.test(nombreRutina.val())) {
    mostrarError(
      nombreRutina,
      "El nombre de la rutina debe tener entre 3 y 16 caracteres y no incluir espacios"
    );
    valido = false;
  }
  if (nivel.val() === 0) {
    mostrarError(nivel, "Debes seleccionar un nivel");
    valido = false;
  }
  return valido;
}

//Funcion para mostrar errores
function mostrarError(elemento, mensaje) {
  let errorSpan = elemento.siblings(".error");
  if (errorSpan.length == 0) {
    elemento.after(`<span class="error" style="color:red;">${mensaje}</span>`);
  } else {
    errorSpan.text(mensaje);
  }
}

function limpiarErrores(...elementos) {
  elementos.forEach((el) => el.siblings(".error").remove());
}

//Envio de datos de inicio de sesion
async function envioDatosInicio(email, contraseña) {
  try {
    let datos = JSON.stringify({ email: email, password: contraseña });
    let url = new URL(
      "assets/php/controlador/controlador_inicio_sesion.php",
      window.location.href
    );
    let opciones = {
      method: "POST",
      body: datos,
      headers: {
        "Content-type": "application/json",
      },
    };

    let response = await fetch(url, opciones);

    if (!response.ok) {
      throw new Error(
        `Error en la solicitud: ${response.status} - ${response.statusText}`
      );
    }

    const data = await response.json();

    if (data.exito) {
      localStorage.setItem("email", email);
      $(".log").show();
      $(".no-log").hide();
      window.location.href = "index.html";
    } else {
      alert(data.message);
    }
  } catch (error) {
    console.error("Hubo un problema con la solicitud:", error);
  }
}

//Envio de datos de registro
async function envioDatosRegistro(usuario, email, contraseña) {
  try {
    let datos = JSON.stringify({
      nombre: usuario,
      email: email,
      password: contraseña,
    });
    let url = new URL(
      "assets/php/controlador/controlador_registro.php",
      window.location.href
    );
    let opciones = {
      method: "POST",
      body: datos,
      headers: {
        "Content-type": "application/json",
      },
    };

    let response = await fetch(url, opciones);
    if (!response.ok) {
      throw new Error("No se ha encontrado el archivo");
    }
    let data = await response.json();

    if (data.exito) {
      localStorage.setItem("email", email);
      $(".log").show();
      $(".no-log").hide();
      window.location.href = "index.html";
    } else {
      alert(data.message);
    }
  } catch (error) {
    console.error("Error en el registro:", error);
    alert("Ocurrió un error al registrarse. Inténtalo de nuevo.");
  }
}

//Envio de datos de nueva contraseña
async function envioContraseña(email, nuevaContraseña) {
  try {
    let datos = JSON.stringify({ email: email, password: nuevaContraseña });
    let url = new URL(
      "assets/php/controlador/controlador_recuperar.php",
      window.location.href
    );
    let opciones = {
      method: "POST",
      body: datos,
      headers: {
        "Content-type": "application/json",
      },
    };

    console.log(datos);
    let response = await fetch(url, opciones);

    console.log(response);
    if (!response.ok) throw new Error("No se ha encontrado el archivo");

    let data = await response.json();

    console.log(data);
    if (data.exito) {
      window.location.href = "inicio_sesion.html";
    } else {
    }
  } catch (error) {
    console.error("Error en el registro de contraseña:", error);
    alert("Ocurrió un error al guardar la contraseña. Inténtalo de nuevo.");
  }
}

/*Funcion para cargar los datos del usuario, recupera los 
datos del usuario logeado y los muestra en el html*/
async function cargarDatos(email) {
  try {
    let url = new URL(
      "assets/php/controlador/controlador_log.php",
      window.location.href
    );
    let datos = JSON.stringify({ email: email });
    let opciones = {
      method: "POST",
      body: datos,
      headers: {
        "Content-type": "application/json",
      },
    };

    let response = await fetch(url, opciones);
    if (!response.ok) throw new Error("No se ha encontrado el archivo");

    let data = await response.json();
    console.log(data);

    if (data.exito) {
      let usuario = data.usuario;
      document.getElementById("nombre_usuario").innerText = usuario.nombre;
      document.getElementById("email_usuario").innerText = usuario.email;
    } else {
      console.error("Error al cargar los datos del usuario");
    }
  } catch (error) {
    console.error("Error al cargar los datos del usuario:", error);
  }
}

//Funcion para cerrar sesion
async function cerrar_sesion() {
  try {
    let url = new URL(
      "assets/php/controlador/cerrar_sesion.php",
      window.location.href
    );
    let response = await fetch(url);
    let data = await response.json();

    if (data.exito) {
      localStorage.removeItem("email");
      $(".log").hide();
      $(".no-log").show();
      window.location.href = "index.html";
    } else {
      alert("Error al cerrar sesión");
    }
  } catch (error) {
    console.error("Error al cerrar sesión:", error);
  }
}

//Funcion para mostrar las advertencias de los ejercicios seleccionados
function datosEjercicios() {
  let selectedOptions = this.selectedOptions;
  let mensajeAdvertencia = "";

  for (let option of selectedOptions) {
    let dificultad = option.getAttribute("data-dificultad");
    if (dificultad == "intermedio" || dificultad == "avanzado") {
      mensajeAdvertencia += `<p><strong>Advertencia:</strong> El ejercicio <em>${option.getAttribute(
        "data-nombre"
      )}</em> es ${dificultad}. Si eres principiante, asegúrate de realizar la técnica correctamente para evitar lesiones.</p>`;
    }
  }

  document.getElementById("advertencias").innerHTML = mensajeAdvertencia;
}

//Funcion para cargar los ejercicios
async function cargarEjercicios() {
  try {
    let url = new URL(
      "assets/php/controlador/controlador_rutina.php",
      window.location.href
    );

    let response = await fetch(url);
    if (!response.ok) {
      throw new Error("No se ha encontrado el archivo");
    }

    console.log(response);
    let data = await response.json();
    console.log(data);
  } catch (error) {
    console.error("Error al cargar los ejercicios:", error);
  }
}

//Funcion para mostrar los ejercicios seleccionados y sus repeticiones y series
function datosEjercicios() {
  let selectedOptions = this.selectedOptions;
  let repeticionesSeriesHTML = "";

  for (let option of selectedOptions) {
    let ejercicioNombre = option.getAttribute("data-nombre");
    repeticionesSeriesHTML += `
            <div class="input-group" id="ejercicio-${option.value}">
                <label for="series-${option.value}">Series para ${ejercicioNombre}:</label>
                <input type="number" id="series-${option.value}" name="series[${option.value}]" value="3" required />
            </div>
            <div class="input-group" id="ejercicio-${option.value}">
                <label for="repeticiones-${option.value}">Repeticiones para ${ejercicioNombre}:</label>
                <input type="number" id="repeticiones-${option.value}" name="repeticiones[${option.value}]" value="10" required />
            </div>
        `;
  }

  document.getElementById("repeticiones-series").innerHTML =
    repeticionesSeriesHTML;
}

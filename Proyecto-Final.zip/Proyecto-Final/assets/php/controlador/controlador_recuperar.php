<?php
require_once '../modelo/usuarios_class.php';

header('Content-Type: application/json');

$usuario = new Usuario();
$json = file_get_contents("php://input");
$datos = json_decode($json, true);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($datos['email'], $datos['password'])) {
    $email = $datos['email'];
    $nuevaPassword = $datos['password'];
    $usuarioExistente = $usuario->get_datos($email);

    if (!$usuarioExistente) {
        echo json_encode([
            'exito' => false,
            'message' => 'El usuario no existe'
        ]);
        exit;
    }
    $resultado = $usuario->actualizarContraseña($email, $nuevaPassword);

    if ($resultado) {
        echo json_encode([
            'exito' => true,
            'message' => 'Contraseña actualizada correctamente'
        ]);
    } else {
        echo json_encode([
            'exito' => false,
            'message' => 'Error al actualizar la contraseña'
        ]);
    }
} else {
    echo json_encode([
        'exito' => false,
        'message' => 'Faltan datos para actualizar la contraseña'
    ]);
}
?>

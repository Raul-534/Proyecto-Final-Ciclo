<?php
require_once '../modelo/rutinas_class.php';
require_once '../modelo/usuarios_class.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $datos = json_decode(file_get_contents("php://input"), true);

    if (isset($datos['idRutina'], $datos['nombreRutina'], $datos['nivelRutina'], $datos['ejercicios'])) {
        $id_rutina = $datos['idRutina'];
        $nombre = $datos['nombreRutina'];
        $nivel = $datos['nivelRutina'];
        $ejercicios = $datos['ejercicios'];

        $rutinas = new Rutinas();

        $rutinas->modificarRutina($id_rutina, $nombre, $nivel);
        $rutinas->eliminarEjerciciosDeRutina($id_rutina);

        foreach ($ejercicios as $ejercicio) {
            $id_ejercicio = $ejercicio['id_ejercicio'];
            $series = $ejercicio['series'];
            $repeticiones = $ejercicio['repeticiones'];
            $descanso = $ejercicio['descanso'];
            $rutinas->insertarEjercicioEnRutina($id_rutina, $id_ejercicio, $series, $repeticiones, $descanso);
        }
        echo json_encode(['exito' => true, 'message' => 'Rutina modificada exitosamente']);
    } else {
        echo json_encode(['exito' => false, 'message' => 'Datos incompletos']);
    }
} else {
    echo json_encode(['exito' => false, 'message' => 'Método no permitido']);
}
?>

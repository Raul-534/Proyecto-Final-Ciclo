<?php
require_once '../modelo/rutinas_class.php';
require_once '../modelo/usuarios_class.php';

header('Content-Type: application/json');
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido', 405);
    }

    $jsonInput = file_get_contents('php://input');
    if (empty($jsonInput)) {
        throw new Exception('No se recibieron datos', 400);
    }

    $data = json_decode($jsonInput, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Error en el formato JSON: ' . json_last_error_msg(), 400);
    }

    if (empty($data['email'])) {
        throw new Exception('Email no proporcionado', 400);
    }

    $usuario = new Usuario();
    $datosUsuario = $usuario->get_datos($data['email']);
    
    if (empty($datosUsuario['id_usuario'])) {
        throw new Exception('Usuario no encontrado', 404);
    }

    $rutinasModel = new Rutinas();
    $rutinas = $rutinasModel->getRutinas($datosUsuario['id_usuario']) ?? [];

    $response = [
        'exito' => true,
        'rutinas' => $rutinas
    ];

    if (ob_get_length()) ob_clean();
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;

} catch (Exception $e) {
    $statusCode = $e->getCode() ?: 500;
    http_response_code($statusCode);
    
    $errorResponse = [
        'exito' => false,
        'mensaje' => $e->getMessage(),
        'codigo' => $statusCode
    ];
    
    if (ob_get_length()) ob_clean();
    echo json_encode($errorResponse, JSON_UNESCAPED_UNICODE);
    exit;
}

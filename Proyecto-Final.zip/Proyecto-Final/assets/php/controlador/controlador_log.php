<?php
session_start();
header('Content-Type: application/json');
require_once '../modelo/usuarios_class.php';

$data = json_decode(file_get_contents('php://input'), true);
if (isset($data['email'])) {
    $email = $data['email'];

    $usuario = new Usuario();
    $datosUsuario = $usuario->get_datos($email);

    if ($datosUsuario) {
        echo json_encode(['exito' => true, 'usuario' => $datosUsuario]);
    } else {
        echo json_encode(['exito' => false, 'message' => 'Usuario no encontrado']);
    }
} else {
    echo json_encode(['exito' => false, 'message' => 'Email no proporcionado']);
}

?>

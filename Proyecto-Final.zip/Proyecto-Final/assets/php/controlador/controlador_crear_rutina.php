<?php
require_once '../modelo/rutinas_class.php';
require_once '../modelo/usuarios_class.php';

header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);

    if (empty($data['email']) || empty($data['nombre']) || empty($data['ejercicios'])) {
        throw new Exception('Faltan datos obligatorios');
    }

    $usuario = new Usuario();
    $datosUsuario = $usuario->get_datos($data['email']);
    if (empty($datosUsuario['id_usuario'])) {
        throw new Exception('Usuario no encontrado');
    }

    $rutinas = new Rutinas();
    $id_rutina = $rutinas->crearRutina(
        $data['nombre'],
        $data['nivel'] ?? 'intermedio',
        $datosUsuario['id_usuario']
    );

    if (!$id_rutina) {
        throw new Exception('Error al crear la rutina principal');
    }

    $ejerciciosInsertados = 0;
    foreach ($data['ejercicios'] as $ej) {
        if (!isset($ej['id_ejercicio']) || !is_numeric($ej['id_ejercicio'])) {
            continue;
        }

        $success = $rutinas->insertarEjercicio(
            $id_rutina,
            (int)$ej['id_ejercicio'],
            (int)($ej['series'] ?? 4),
            (int)($ej['repeticiones'] ?? 10),
            (int)($ej['descanso'] ?? 60)
        );

        if ($success) {
            $ejerciciosInsertados++;
        }
    }

    if ($ejerciciosInsertados === 0) {
        throw new Exception('No se insertaron ejercicios. Verifica que los IDs existan');
    }

    echo json_encode([
        'exito' => true,
        'mensaje' => "Rutina creada con $ejerciciosInsertados ejercicios",
        'id_rutina' => $id_rutina
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'exito' => false,
        'mensaje' => $e->getMessage()
    ]);
}
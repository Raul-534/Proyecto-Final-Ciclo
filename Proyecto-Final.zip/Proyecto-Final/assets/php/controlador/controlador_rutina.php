<?php
require_once '../modelo/ejercicios_class.php';
session_start();

$ejercicios = new Ejercicios();
$datos = $ejercicios->get_ejercicios();
echo json_encode($datos);
?>

<?php
require_once '../modelo/ejercicios_class.php';
session_start();

header('Content-Type: application/json');

$ejercicios = new Ejercicios();
$datos = $ejercicios->get_ejercicios();
echo json_encode($datos);
?>

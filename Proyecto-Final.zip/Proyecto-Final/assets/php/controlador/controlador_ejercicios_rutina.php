<?php
require_once '../modelo/rutinas_class.php';

header('Content-Type: application/json');

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        throw new Exception('Método no permitido', 405);
    }

    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
        throw new Exception('ID de rutina inválido', 400);
    }

    $id_rutina = (int)$_GET['id'];
    $rutinasModel = new Rutinas();
    $ejercicios = $rutinasModel->getEjerciciosRutina($id_rutina);

    echo json_encode([
        'exito' => true,
        'ejercicios' => $ejercicios
    ]);

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    echo json_encode([
        'exito' => false,
        'mensaje' => $e->getMessage()
    ]);
}
<?php
require_once '../modelo/rutinas_class.php';

header('Content-Type: application/json');

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido', 405);
    }

    $jsonInput = file_get_contents('php://input');
    if (empty($jsonInput)) {
        throw new Exception('No se recibieron datos', 400);
    }

    $data = json_decode($jsonInput, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Error en el formato JSON: ' . json_last_error_msg(), 400);
    }

    if (empty($data['id_rutina'])) {
        throw new Exception('ID de rutina no proporcionado', 400);
    }

    $id_rutina = (int) $data['id_rutina'];
    $rutinas = new Rutinas();

    $rutinas->eliminarEjerciciosDeRutina($id_rutina);

    $eliminado = $rutinas->eliminarRutina($id_rutina);

    if (!$eliminado) {
        throw new Exception('No se pudo eliminar la rutina', 500);
    }

    echo json_encode([
        'exito' => true,
        'mensaje' => 'Rutina eliminada correctamente'
    ]);

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    echo json_encode([
        'exito' => false,
        'mensaje' => $e->getMessage()
    ]);
}

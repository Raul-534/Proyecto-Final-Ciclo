<?php
class Ejercicios extends Conexion{
    
}
?>
<?php
class Ejercicios extends Conexion {
    private $conexion;

    public function __construct() {
        $this->conexion = new Conexion();
    }

    public function get_ejercicios() {
        $sql = "SELECT nombre, descripcion, equipamiento, dificultad FROM ejercicios";
        $stmt = $this->conexion->getConexion()->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

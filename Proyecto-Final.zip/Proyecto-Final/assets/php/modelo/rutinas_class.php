<?php
class Rutinas extends Conexion{
    
}
?>
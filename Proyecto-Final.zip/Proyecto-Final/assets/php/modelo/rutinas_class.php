<?php
require_once 'bd_class.php';

class Rutinas
{
    private $conexion;

    public function __construct()
    {
        $this->conexion = (new Conexion())->getConexion();
    }

    public function crearRutina($nombre, $nivel, $id_usuario)
    {
        try {
            $stmt = $this->conexion->prepare(
                "INSERT INTO rutinas (nombre, nivel, id_usuario) VALUES (:nombre, :nivel, :id_usuario)"
            );
            $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
            $stmt->bindParam(':nivel', $nivel, PDO::PARAM_STR);
            $stmt->bindParam(':id_usuario', $id_usuario, PDO::PARAM_INT);

            if ($stmt->execute()) {
                return $this->conexion->lastInsertId();
            } else {
                return false;
            }
        } catch (PDOException $e) {
            error_log("Error al crear rutina: " . $e->getMessage());
            return false;
        }
    }

    public function insertarEjercicio($id_rutina, $id_ejercicio, $series, $repeticiones, $descanso)
{
    try {
        $stmtCheck = $this->conexion->prepare(
            "SELECT id_ejercicio FROM ejercicios WHERE id_ejercicio = ?"
        );
        $stmtCheck->execute([$id_ejercicio]);
        
        if ($stmtCheck->rowCount() == 0) {
            error_log("Ejercicio no encontrado: $id_ejercicio");
            return false;
        }

        $stmtInsert = $this->conexion->prepare(
            "INSERT INTO rutina_ejercicios 
            (id_rutina, id_ejercicio, series, repeticiones, descanso) 
            VALUES (?, ?, ?, ?, ?)"
        );
        
        $stmtInsert->execute([
            $id_rutina,
            $id_ejercicio,
            $series,
            $repeticiones,
            $descanso
        ]);

        return true;
    } catch (PDOException $e) {
        error_log("Error en insertarEjercicio: " . $e->getMessage());
        return false;
    }
}

    public function getRutinas($id_usuario)
    {
        try {
            $stmt = $this->conexion->prepare(
                "SELECT * FROM rutinas WHERE id_usuario = :id_usuario"
            );
            $stmt->bindParam(':id_usuario', $id_usuario, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error al obtener rutinas: " . $e->getMessage());
            return [];
        }
    }
    
    public function eliminarRutina($id_rutina) {
        try {
            $stmtEjercicios = $this->conexion->prepare(
                "DELETE FROM rutina_ejercicios WHERE id_rutina = :id_rutina"
            );
            $stmtEjercicios->bindParam(':id_rutina', $id_rutina, PDO::PARAM_INT);
            $stmtEjercicios->execute();
            
            $stmtRutina = $this->conexion->prepare(
                "DELETE FROM rutinas WHERE id_rutina = :id_rutina"
            );
            $stmtRutina->bindParam(':id_rutina', $id_rutina, PDO::PARAM_INT);
            
            return $stmtRutina->execute();
        } catch (PDOException $e) {
            error_log("Error al eliminar rutina: " . $e->getMessage());
            return false;
        }
    }
    public function getEjerciciosRutina($id_rutina) {
        try {
            $stmtEjercicios = $this->conexion->prepare(
                "SELECT id_ejercicio, series, repeticiones, descanso 
                 FROM rutina_ejercicios 
                 WHERE id_rutina = :id_rutina"
            );
            $stmtEjercicios->bindParam(':id_rutina', $id_rutina, PDO::PARAM_INT);
            $stmtEjercicios->execute();
            $ejerciciosRutina = $stmtEjercicios->fetchAll(PDO::FETCH_ASSOC);
    
            if (empty($ejerciciosRutina)) {
                return [];
            }
    
            $idsEjercicios = array_column($ejerciciosRutina, 'id_ejercicio');
            $placeholders = implode(',', array_fill(0, count($idsEjercicios), '?'));
            
            $stmtDetalles = $this->conexion->prepare(
                "SELECT id_ejercicio, nombre, descripcion, equipamiento, dificultad 
                 FROM ejercicios 
                 WHERE id_ejercicio IN ($placeholders)"
            );
            $stmtDetalles->execute($idsEjercicios);
            $detallesEjercicios = $stmtDetalles->fetchAll(PDO::FETCH_ASSOC);
    
            $resultado = [];
            foreach ($ejerciciosRutina as $ejRutina) {
                foreach ($detallesEjercicios as $detalle) {
                    if ($ejRutina['id_ejercicio'] == $detalle['id_ejercicio']) {
                        $resultado[] = array_merge($ejRutina, $detalle);
                        break;
                    }
                }
            }
    
            return $resultado;
    
        } catch (PDOException $e) {
            error_log("Error al obtener ejercicios: " . $e->getMessage());
            return [];
        }
    }
    public function getIdEjercicioPorNombre($nombre) {
        try {
            $stmt = $this->conexion->prepare("SELECT id_ejercicio FROM ejercicios WHERE nombre = ?");
            $stmt->execute([$nombre]);
            $fila = $stmt->fetch(PDO::FETCH_ASSOC);
            return $fila ? $fila["id_ejercicio"] : null;
        } catch (PDOException $e) {
            error_log("Error en getIdEjercicioPorNombre: " . $e->getMessage());
            return null;
        }
    }
    
    public function insertarEjercicioEnRutina($id_rutina, $id_ejercicio, $series, $repeticiones, $descanso) {
        return $this->insertarEjercicio($id_rutina, $id_ejercicio, $series, $repeticiones, $descanso);
    }

    public function eliminarEjerciciosDeRutina($id_rutina) {
        try {
            $stmt = $this->conexion->prepare("DELETE FROM rutina_ejercicios WHERE id_rutina = ?");
            $stmt->execute([$id_rutina]);
        } catch (PDOException $e) {
            error_log("Error al eliminar ejercicios de rutina: " . $e->getMessage());
        }
    }
    
    public function modificarRutina($id_rutina, $nombre, $nivel) {
        try {
            $stmt = $this->conexion->prepare("UPDATE rutinas SET nombre = ?, nivel = ? WHERE id_rutina = ?");
            $stmt->execute([$nombre, $nivel, $id_rutina]);
        } catch (PDOException $e) {
            error_log("Error al modificar rutina: " . $e->getMessage());
        }
    }
}

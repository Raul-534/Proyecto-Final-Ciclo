<?php
require_once 'bd_class.php';

class Usuario
{
    private $conexion;

    public function __construct()
    {
        $this->conexion = new Conexion();
    }

    public function get_datos($email)
    {
        $stmt = $this->conexion->getConexion()->prepare("SELECT id_usuario, nombre, email, contraseña FROM usuarios WHERE email = :email");
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function registrar($nombre, $email, $password)
    {
        if ($this->get_datos($email)) {
            return ['exito' => false, 'message' => 'El usuario ya está registrado'];
        }

        $stmt = $this->conexion->getConexion()->prepare("INSERT INTO usuarios (nombre, email, contraseña) VALUES (:nombre, :email, :password)");
        $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':password', $password, PDO::PARAM_STR);

        if ($stmt->execute()) {
            return ['exito' => true, 'message' => 'Registro exitoso'];
        } else {
            return ['exito' => false, 'message' => 'Error en el registro'];
        }
    }

    public function verificarCredenciales($email, $password)
    {
        $usuario = $this->get_datos($email);

        if (!$usuario) {
            return ['exito' => false, 'message' => 'Usuario no encontrado'];
        }

        if ($password != $usuario['contraseña']) {
            return ['exito' => false, 'message' => 'Contraseña incorrecta'];
        }

        return [
            'exito' => true,
            'id_usuario' => $usuario['id_usuario'],
            'nombre' => $usuario['nombre']
        ];
    }

    public function actualizarContraseña($email, $nuevaPassword)
    {
        $stmt = $this->conexion->getConexion()->prepare("UPDATE usuarios SET contraseña = :password WHERE email = :email");
        $stmt->bindParam(':password', $nuevaPassword, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        return $stmt->execute();
    }
}
